from mido import MidiFile
import os
from numpy import empty
from tqdm import tqdm
import json
from mido import MidiFile
import pickle
import pandas as pd

""" 
object = pd.read_pickle("./dataset/e_piano/train/Tracie.mid.pickle")
print(object[:10])

os.chdir('./dataset/e_piano')
 """
MIDPICLength = []
total = 0
for file in tqdm(os.listdir('./dataset/e_piano/train')):
        object = pd.read_pickle('./dataset/e_piano/train/'+file)
        total += 1
        if len(object) != 0:
            MIDPICLength.append(len(object))

print(total)
print(len(MIDPICLength))
avg = sum(MIDPICLength)/len(MIDPICLength)
print("The average is ", round(avg,2))















#MIDLength = []
#for file in tqdm(os.listdir('./dataset/Jazz_Midi')):
#    pather = ""
#    try:
#        pather = "./dataset/Jazz_Midi/"+file
#        mid = MidiFile(pather)
#        MIDLength.append(mid.length)
#    except KeyboardInterrupt:
#        raise
#    except:
#        print("Skip")

#avg = sum(MIDLength)/len(MIDLength)
#print("The average is ", round(avg,2))
#The resulting average is 242.66       


""" 
os.chdir('./dataset')
file_path = os.path.realpath(__file__)
print(file_path)
failed = []
for filename in tqdm(os.listdir('./Jazz_Midi')):
     pather = ""
     try:
         pather = "./dataset/Jazz_Midi/"+filename
         MidiFile(pather)
         print("Succesfully loaded " +pather)
     except (OSError, ValueError) as e:
         print("Couldnt load " +pather)
         failed.append(pather)
 """
#failed.remove('./dataset/Jazz_Midi/Jazz-midi.csv')    
#failed.remove('./dataset/Jazz_Midi/Jazzy-midi.csv')
#failed.remove('./dataset/Jazz_Midi/Jazzy-midi.json')

#new_failed = []
#for d in failed:
#    x = d.replace("./dataset/Jazz_Midi/","")
#    new_failed.append(x)

#print(new_failed) 
                   
""" obj  = json.load(open('./dataset/Jazz_Midi/Jazzy-midi.json'))

# Iterate through the objects in the JSON and pop (remove)                      
# the obj once we find it.                                                      
for i in range(len(obj)):
    for x in new_failed:
        if obj[i]["midi_filename"] == x:
            obj.pop(i)


# Output the updated file with pretty JSON                                      
open("updated-file.json", "w").write(
    json.dumps(obj, sort_keys=True, indent=4, separators=(',', ': '))
) """





#MidiFile('./dataset/Jazz_Midi/2ndMovementOfSinisterFootwear.mid')