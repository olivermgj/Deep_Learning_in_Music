import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import warnings

# read file
df = pd.read_csv('./dataset/Jazz-midi.csv', index_col=0)
unique_notes = df.Unique_notes
file_name = df.midi_filename
len_uni_notes = df.len_Uni_Notes

# drop Notes columns.
df = df.drop(columns=['Notes'])
# drop songs which has less than 32 notes.
df = df.drop(df[df.Len_Sequence <= 32].index)

def get_name(fn):
    words = []
    first = 0 
    for i in range(1, len(fn)-4):     
        if fn[i].isupper() and first<i:
            words.append(fn[first:i])
            first = i  
    words.append(fn[first:len(fn)-4])
    return ' '.join(words)

def filter_numbers(notes):
    ret = []
    notes = notes[1:-1].split(',')
    for note in notes: 
        note = note.strip()
        if not note[1].isdigit():
            ret.append(note[1:-1])
    return ret
    
# insert name column.
name = file_name.apply(get_name)
df.insert(0, 'Song', name)
# update unique_notes column.
unique_notes = unique_notes.apply(filter_numbers)
df.update(unique_notes)
# update len_uni_notes column.
df.update(pd.Series(name='len_Uni_Notes', data=unique_notes.apply(lambda x: len(x))))
# drop songs with invalid notes.
df = df.drop(df[df.len_Uni_Notes <= 1].index)
# rename names.
df = df.rename(columns={'Name':'file_name', 'Song':'Name', 'Len_Sequence':'len_sequence',
                        'Unique_notes':'unique_notes' ,'len_Uni_Notes':'len_uni_notes'})

print('Setup Complete!\n')
# df.to_csv('/Users/todd/Downloads/jazz_notes.csv',)
# calculate depth
warnings.simplefilter(action='ignore', category=FutureWarning)
level = lambda x: (ord(x[0]) - ord('A')) * int(x[-1]) 
depth = pd.Series(data=[level(max(notes))-level(min(notes)) for notes in df['unique_notes']], dtype=int, name='Depth')
# calculate length
length = pd.Series(data=df['len_sequence'], dtype=int, name='Length')
# calculate chromaticity
chromaticity = pd.Series(data=df['len_uni_notes'], dtype=int, name='Chromaticity').dropna()
# calculate major
major = []
for notes in df['unique_notes']:
    scale = {}
    for note in notes:
        scale[note[-1]] = scale[note[-1]] + 1 if scale.__contains__(note[-1]) else 1
    major.append(max(scale, key=scale.get))

for i in range(0, len(major)):
    major[i] = int(major[i])
major = pd.Series(data=major, dtype=int, name='Major')

# define features
features = pd.concat([depth, length, chromaticity, major], axis=1)
features = features.dropna()
features.index = range(len(features))
depth, length, chromaticity, major = features['Depth'], features['Length'], features['Chromaticity'], features['Major']
print("Completed")
TAGS = [['Classic','Exotic'], ['Ceased', 'Progressive', 'Epic'], ['Peaceful','Vivid'], ['Bassy','Harmony','Trebly']]
    
get_conds = lambda idx: [[depth[idx]>=16 and depth[idx]<=32],\
            [length[idx]<300, length[idx]>3500],\
            [chromaticity[idx]<=32],\
            [major[idx]<=2, major[idx]>=6]]
df = df.reset_index(drop=True)
def get_tags(idx):
    conds = get_conds(idx)
    tags = []
    #try:
    #    tags.append(df.midi_filename[idx])
    #except KeyError:
    #    print("Faulty index number"+str(idx))
    if conds[0][0]:
        tags.append(TAGS[0][0])
    else:
        tags.append(TAGS[0][1])
        
    if conds[1][0]:
        tags.append(TAGS[1][0])
    elif conds[1][1]:
        tags.append(TAGS[1][2])
    else:
        tags.append(TAGS[1][1])
    
    if conds[2][0]:
        tags.append(TAGS[2][0])
    else:
        tags.append(TAGS[2][1])
    
    if conds[3][0]:
        tags.append(TAGS[3][0])
    elif conds[3][1]:
        tags.append(TAGS[3][2])
    else:
        tags.append(TAGS[3][1])
            
    return tags

tags = pd.Series(data=[' '.join(get_tags(idx)) for idx in features.index], name='Tags')
tags.to_pickle("./Moody.pkl")
