#@title Process your custom MIDI DataSet :)
#%cd /content/MusicTransformer-Pytorch
import third_party.midi_processor.processor as midi_processor
from third_party.midi_processor.processor import encode_midi 
import os
import random
import pickle


os.chdir('C:/Users/Usuario/Desktop/HWUni/Dissertation/Code/Thing/MusicTransformer-Pytorch/dataset/Jazz_Midi')
#%cd '/content/MusicTransformer-Pytorch/dataset/e_piano/custom_midis

custom_MIDI_DataSet_dir = 'C:/Users/Usuario/Desktop/HWUni/Dissertation/Code/Thing/MusicTransformer-Pytorch/dataset/Jazz_Midi'

train_dir = 'C:/Users/Usuario/Desktop/HWUni/Dissertation/Code/Thing/MusicTransformer-Pytorch/dataset/e_piano/train' # split_type = 0
test_dir = 'C:/Users/Usuario/Desktop/HWUni/Dissertation/Code/Thing/MusicTransformer-Pytorch/dataset/e_piano/test' # split_type = 1  
val_dir = 'C:/Users/Usuario/Desktop/HWUni/Dissertation/Code/Thing/MusicTransformer-Pytorch/dataset/e_piano/val' # split_type = 2

total_count = 0
train_count = 0
val_count   = 0
test_count  = 0

f_ext = '.pickle'
fileList = os.listdir(custom_MIDI_DataSet_dir)
for file in fileList:
     # we gonna split by a random selection for now
    
    split = random.randint(1, 2)
    if (split == 0):
         o_file = os.path.join(train_dir, file+f_ext)
         train_count += 1

    elif (split == 2):
         o_file0 = os.path.join(train_dir, file+f_ext)
         train_count += 1
         o_file = os.path.join(val_dir, file+f_ext)
         val_count += 1

    elif (split == 1):
         o_file0 = os.path.join(train_dir, file+f_ext)
         train_count += 1
         o_file = os.path.join(test_dir, file+f_ext)
         test_count += 1
    try:
      prepped = encode_midi(file)
      o_stream = open(o_file0, "wb")
      pickle.dump(prepped, o_stream)
      o_stream.close()

      prepped = encode_midi(file)
      o_stream = open(o_file, "wb")
      pickle.dump(prepped, o_stream)
      o_stream.close()
   
      print(file)
      print(o_file)
      print('Coverted!')  
    except KeyboardInterrupt: 
      raise   
    #except:
     #print('Bad file. Skipping...')

print('Done')
print("Num Train:", train_count)
print("Num Val:", val_count)
print("Num Test:", test_count)
print("Total Count:", train_count)

#%cd /content/MusicTransformer-Pytorch