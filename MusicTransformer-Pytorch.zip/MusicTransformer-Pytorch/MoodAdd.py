import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

import sys

object = pd.read_pickle('./dataset/Jazz_prepro/test/Angela.mid.pickle')
object.append(20)
print(object)