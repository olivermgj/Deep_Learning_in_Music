import pandas as pd
import json

#Create dataframe
df = pd.read_csv("./dataset/Jazz Midi/csv/Jazz-midi.csv")
#New column split populated with train
df["split"] = "train"
#Split 80/20 train/test
df["split"][int((len(df.index))*0.8):len(df.index)] = "test"



df = df.drop(df.columns[[2,3,4]], axis=1)
#print(df)
#row = df.iloc[800]
#print(len(df))
#print(row)
df.to_csv("./dataset/Jazz Midi/csv/Jazzy-midi.csv")